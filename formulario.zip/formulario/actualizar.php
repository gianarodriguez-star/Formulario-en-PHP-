<?php

include("conexion.php");

$id = $_POST['id'];

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$email = $_POST['email'];

$facultad = $_POST['facultad'];
$sexo = $_POST['sexo'];
$observacion = $_POST['observacion'];

if(isset($_POST['lenguajes'])){

    $lenguajes = implode(", ", $_POST['lenguajes']);

}else{

    $lenguajes = "Ninguno";
}

$sql = "UPDATE estudiantes SET

nombre = '$nombre',
apellido = '$apellido',
email = '$email',
lenguajes = '$lenguajes',
facultad = '$facultad',
sexo = '$sexo',
observacion = '$observacion'

WHERE id = '$id'
";

$resultado = mysqli_query($conexion, $sql);

if($resultado){

    echo "
        <h2>Datos actualizados correctamente</h2>

        <a href='listado.php'>
            Ver listado
        </a>
    ";

}else{

    echo "Error: " . mysqli_error($conexion);
}

?>