<?php

include("conexion.php");

$id = $_GET['id'];

$sql = "DELETE FROM estudiantes WHERE id = '$id'";

$resultado = mysqli_query($conexion, $sql);

/* Verificar */
if($resultado){

    echo "
        <h2>Registro eliminado correctamente</h2>

        <a href='listado.php'>
            Volver al listado
        </a>
    ";

}else{

    echo "Error al eliminar: " . mysqli_error($conexion);
}

?>